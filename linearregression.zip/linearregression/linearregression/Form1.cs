﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MathNet.Numerics;
using MathNet.Numerics.LinearAlgebra;

namespace linearregression
{
    public partial class Form1 : Form
    {
        List<double> xdata = new List<double>();
        List<double> ydata = new List<double>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var M = Matrix<double>.Build;
            var V = Vector<double>.Build;
            foreach(string s in textBox1.Text.Split('?'))
            {
                xdata.Add(Convert.ToDouble(s));
            }
            foreach (string s in textBox2.Text.Split('?'))
            {
                ydata.Add(Convert.ToDouble(s));
            }
            var X = M.DenseOfColumnVectors(V.Dense(xdata.ToArray().Length,1.0),V.Dense(xdata.ToArray()));
            var y = V.Dense(ydata.ToArray());
            var p = X.QR().Solve(y);
            double a = p[0];
            double b = p[1];
            MessageBox.Show(a.ToString());
            MessageBox.Show(b.ToString());
        }
    }
}
